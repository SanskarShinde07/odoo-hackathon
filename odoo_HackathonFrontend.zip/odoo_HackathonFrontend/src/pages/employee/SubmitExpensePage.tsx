import { useState, useEffect, useRef } from 'react'
import {
  Box, Card, CardContent, TextField, Button, Typography,
  Select, MenuItem, FormControl, InputLabel, FormHelperText,
  Alert, Snackbar, Stack, Divider, IconButton, Chip,
   CircularProgress, Tooltip,
} from '@mui/material'
import {
  AttachFile, DocumentScanner, Close, CurrencyExchange,
} from '@mui/icons-material'
import { PageHeader } from '../../components/common/PageHeader'
import { useExpenses } from '../../hooks/useExpenses'
import { useAuthContext } from '../../context/AuthContext'
import type { ExpenseCategory } from '../../types'
import { getCategoryLabel } from '../../utils/formatter'

const CATEGORIES: ExpenseCategory[] = [
  'TRAVEL', 'FOOD', 'ACCOMMODATION', 'OFFICE_SUPPLIES', 'ENTERTAINMENT', 'MISCELLANEOUS',
]

const COMMON_CURRENCIES = ['INR', 'USD', 'EUR', 'GBP', 'AED', 'SGD', 'JPY', 'AUD', 'CAD']

export default function SubmitExpensePage() {
  const { user } = useAuthContext()
  const { submitExpense, submitting, error } = useExpenses()
  const fileRef = useRef<HTMLInputElement>(null)

  const [amount, setAmount] = useState('')
  const [currency, setCurrency] = useState('INR')
  const [category, setCategory] = useState<ExpenseCategory | ''>('')
  const [description, setDescription] = useState('')
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [receiptFile, setReceiptFile] = useState<File | null>(null)
  const [ocrLoading, setOcrLoading] = useState(false)
  const [exchangeRate, setExchangeRate] = useState<number | null>(null)
  const [companyCurrency] = useState('INR') // TODO: get from company context
  const [success, setSuccess] = useState(false)

  // ── Fetch exchange rate when currency changes ────────────────────────────
  useEffect(() => {
    if (currency === companyCurrency) {
      setExchangeRate(null)
      return
    }
    let cancelled = false
    async function fetchRate() {
      try {
        // TODO: replace with real API call
        // const res = await fetch(`https://api.exchangerate-api.com/v4/latest/${currency}`)
        // const data = await res.json()
        // setExchangeRate(data.rates[companyCurrency])
        await new Promise((r) => setTimeout(r, 400))
        if (!cancelled) {
          // Mock rates vs INR
          const mockRates: Record<string, number> = {
            USD: 83.5, EUR: 90.2, GBP: 105.1, AED: 22.7, SGD: 62.3,
            JPY: 0.56, AUD: 54.1, CAD: 61.8,
          }
          setExchangeRate(mockRates[currency] ?? 1)
        }
      } catch {
        if (!cancelled) setExchangeRate(null)
      }
    }
    fetchRate()
    return () => { cancelled = true }
  }, [currency, companyCurrency])

  const convertedAmount =
    exchangeRate && amount ? (parseFloat(amount) * exchangeRate).toFixed(2) : null

  // ── OCR placeholder ──────────────────────────────────────────────────────
  const handleOcr = async () => {
    if (!receiptFile) return
    setOcrLoading(true)
    try {
      // TODO: POST receiptFile to OCR endpoint
      // const formData = new FormData()
      // formData.append('receipt', receiptFile)
      // const res = await axios.post('/api/expenses/ocr', formData)
      // auto-fill fields from res.data
      await new Promise((r) => setTimeout(r, 1200))
      // Mock OCR fill
      setAmount('1250')
      setCategory('FOOD')
      setDescription('Restaurant bill – Lunch meeting')
      setDate(new Date().toISOString().split('T')[0])
    } finally {
      setOcrLoading(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] ?? null
    setReceiptFile(file)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!category) return
    await submitExpense({
      amount: parseFloat(amount),
      currency,
      category,
      description,
      date,
      receiptFile: receiptFile ?? undefined,
    })
    // Reset form
    setAmount('')
    setCategory('')
    setDescription('')
    setDate(new Date().toISOString().split('T')[0])
    setReceiptFile(null)
    setExchangeRate(null)
    setSuccess(true)
  }

  return (
    <Box>
      <PageHeader
        title="Submit Expense"
        subtitle={`Hello ${user?.name ?? 'there'} — fill in the details below to submit a reimbursement claim.`}
      />

      <Card elevation={0} sx={{ border: '1px solid', borderColor: 'divider', maxWidth: 640 }}>
        <CardContent sx={{ p: 3 }}>
          {error && (
            <Alert severity="error" sx={{ mb: 2.5, fontSize: '0.82rem' }}>
              {error}
            </Alert>
          )}

          <Box component="form" onSubmit={handleSubmit}>
            <Stack spacing={2.5}>
              {/* Amount + Currency row */}
              <Stack direction="row" spacing={1.5}>
                <TextField
                  label="Amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  required
                  inputProps={{ min: 0, step: '0.01' }}
                  sx={{ flex: 1 }}
                />
                <FormControl sx={{ minWidth: 110 }}>
                  <InputLabel>Currency</InputLabel>
                  <Select
                    label="Currency"
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                  >
                    {COMMON_CURRENCIES.map((c) => (
                      <MenuItem key={c} value={c}>{c}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Stack>

              {/* Exchange rate info */}
              {convertedAmount && exchangeRate && (
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                    px: 1.5,
                    py: 1,
                    borderRadius: 2,
                    backgroundColor: 'info.light',
                  }}
                >
                  <CurrencyExchange sx={{ fontSize: 16, color: 'info.main' }} />
                  <Typography variant="caption" sx={{ color: 'info.main', fontWeight: 500 }}>
                    ≈ {companyCurrency} {convertedAmount} at {exchangeRate} {companyCurrency}/{currency}
                  </Typography>
                </Box>
              )}

              {/* Category */}
              <FormControl required fullWidth>
                <InputLabel>Category</InputLabel>
                <Select
                  label="Category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                >
                  {CATEGORIES.map((c) => (
                    <MenuItem key={c} value={c}>{getCategoryLabel(c)}</MenuItem>
                  ))}
                </Select>
                <FormHelperText>Select the expense category</FormHelperText>
              </FormControl>

              {/* Date */}
              <TextField
                label="Expense date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                fullWidth
                InputLabelProps={{ shrink: true }}
                inputProps={{ max: new Date().toISOString().split('T')[0] }}
              />

              {/* Description */}
              <TextField
                label="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                fullWidth
                multiline
                rows={2}
                placeholder="Brief description of the expense..."
              />

              <Divider />

              {/* Receipt upload */}
              <Box>
                <Typography variant="body2" sx={{ fontWeight: 500, mb: 1 }}>
                  Receipt{' '}
                  <Typography component="span" variant="caption" color="text.secondary">
                    (optional)
                  </Typography>
                </Typography>

                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*,application/pdf"
                  hidden
                  onChange={handleFileChange}
                />

                {receiptFile ? (
                  <Box
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 1,
                      px: 1.5,
                      py: 1,
                      border: '1px solid',
                      borderColor: 'divider',
                      borderRadius: 2,
                    }}
                  >
                    <AttachFile sx={{ fontSize: 16, color: 'text.secondary' }} />
                    <Typography variant="caption" sx={{ flex: 1 }} noWrap>
                      {receiptFile.name}
                    </Typography>
                    <Tooltip title="Scan receipt with OCR">
                      <span>
                        <IconButton
                          size="small"
                          onClick={handleOcr}
                          disabled={ocrLoading}
                          sx={{ color: 'primary.main' }}
                        >
                          {ocrLoading ? (
                            <CircularProgress size={16} />
                          ) : (
                            <DocumentScanner fontSize="small" />
                          )}
                        </IconButton>
                      </span>
                    </Tooltip>
                    <IconButton size="small" onClick={() => setReceiptFile(null)}>
                      <Close fontSize="small" />
                    </IconButton>
                  </Box>
                ) : (
                  <Stack direction="row" spacing={1}>
                    <Button
                      variant="outlined"
                      size="small"
                      startIcon={<AttachFile />}
                      onClick={() => fileRef.current?.click()}
                    >
                      Attach receipt
                    </Button>
                    <Chip
                      label="OCR auto-fill"
                      size="small"
                      color="primary"
                      variant="outlined"
                      icon={<DocumentScanner />}
                      onClick={() => fileRef.current?.click()}
                      sx={{ cursor: 'pointer' }}
                    />
                  </Stack>
                )}
                {ocrLoading && (
                  <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
                    Scanning receipt… fields will be auto-filled
                  </Typography>
                )}
              </Box>

              <Button
                type="submit"
                variant="contained"
                fullWidth
                disabled={submitting}
                sx={{ py: 1.1, fontWeight: 600 }}
              >
                {submitting ? 'Submitting…' : 'Submit expense'}
              </Button>
            </Stack>
          </Box>
        </CardContent>
      </Card>

      <Snackbar
        open={success}
        autoHideDuration={4000}
        onClose={() => setSuccess(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity="success" onClose={() => setSuccess(false)} sx={{ fontWeight: 500 }}>
          Expense submitted successfully! It's now pending approval.
        </Alert>
      </Snackbar>
    </Box>
  )
}
