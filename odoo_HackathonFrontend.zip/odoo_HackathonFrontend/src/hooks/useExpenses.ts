import { useState, useCallback } from 'react'
import type { Expense, SubmitExpensePayload } from '../types'

interface UseExpensesReturn {
  expenses: Expense[]
  loading: boolean
  error: string | null
  submitting: boolean
  fetchMyExpenses: () => Promise<void>
  submitExpense: (payload: SubmitExpensePayload) => Promise<void>
}

// Mock data for placeholder
const MOCK_EXPENSES: Expense[] = [
  {
    id: 'e1',
    employeeId: '1',
    employeeName: 'Demo User',
    amount: 2500,
    currency: 'INR',
    amountInCompanyCurrency: 2500,
    companyCurrency: 'INR',
    category: 'TRAVEL',
    description: 'Cab to client office',
    date: '2025-03-15',
    status: 'APPROVED',
    currentApproverStep: 1,
    totalApproverSteps: 1,
    comments: [],
    createdAt: '2025-03-15T10:00:00Z',
  },
  {
    id: 'e2',
    employeeId: '1',
    employeeName: 'Demo User',
    amount: 800,
    currency: 'INR',
    amountInCompanyCurrency: 800,
    companyCurrency: 'INR',
    category: 'FOOD',
    description: 'Team lunch',
    date: '2025-03-18',
    status: 'IN_REVIEW',
    currentApproverStep: 1,
    totalApproverSteps: 2,
    comments: [],
    createdAt: '2025-03-18T12:00:00Z',
  },
  {
    id: 'e3',
    employeeId: '1',
    employeeName: 'Demo User',
    amount: 150,
    currency: 'USD',
    amountInCompanyCurrency: 12500,
    companyCurrency: 'INR',
    category: 'ACCOMMODATION',
    description: 'Hotel stay - Bangalore trip',
    date: '2025-03-20',
    status: 'PENDING',
    currentApproverStep: 0,
    totalApproverSteps: 3,
    comments: [],
    createdAt: '2025-03-20T08:00:00Z',
  },
]

export function useExpenses(): UseExpensesReturn {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  // ── Fetch employee's own expenses ──────────────────────────────────────────
  const fetchMyExpenses = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // const res = await axios.get<ApiResponse<Expense[]>>('/api/expenses/me', {
      //   headers: { Authorization: `Bearer ${token}` }
      // })
      // setExpenses(res.data.data)

      await new Promise((r) => setTimeout(r, 600))
      setExpenses(MOCK_EXPENSES)
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to fetch expenses.')
    } finally {
      setLoading(false)
    }
  }, [])

  // ── Submit a new expense ───────────────────────────────────────────────────
  const submitExpense = async (payload: SubmitExpensePayload) => {
    setSubmitting(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // const formData = new FormData()
      // formData.append('amount', String(payload.amount))
      // formData.append('currency', payload.currency)
      // formData.append('category', payload.category)
      // formData.append('description', payload.description)
      // formData.append('date', payload.date)
      // if (payload.receiptFile) formData.append('receipt', payload.receiptFile)
      //
      // const res = await axios.post<ApiResponse<Expense>>(
      //   '/api/expenses', formData,
      //   { headers: { 'Content-Type': 'multipart/form-data' } }
      // )

      await new Promise((r) => setTimeout(r, 900))
      console.log('submitExpense placeholder', payload)
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to submit expense.')
      throw err
    } finally {
      setSubmitting(false)
    }
  }

  return { expenses, loading, error, submitting, fetchMyExpenses, submitExpense }
}