import { useState, useCallback } from 'react'
import type { ApprovalRule, CreateApprovalRulePayload } from '../types'

interface UseApprovalRulesReturn {
  rules: ApprovalRule[]
  loading: boolean
  actionLoading: boolean
  error: string | null
  fetchRules: () => Promise<void>
  createRule: (payload: CreateApprovalRulePayload) => Promise<void>
  updateRule: (id: string, payload: Partial<CreateApprovalRulePayload>) => Promise<void>
  deleteRule: (id: string) => Promise<void>
}

const MOCK_RULES: ApprovalRule[] = [
  {
    id: 'r1',
    companyId: 'c1',
    name: 'Standard Approval',
    isManagerApprover: true,
    approvers: [
      { stepNumber: 1, userId: '2', userName: 'Riya Sharma', userRole: 'MANAGER' },
      { stepNumber: 2, userId: '5', userName: 'Finance Team', userRole: 'MANAGER' },
    ],
    approvalSequence: true,
    conditionType: 'SEQUENTIAL',
    createdAt: '2025-01-01T00:00:00Z',
  },
  {
    id: 'r2',
    companyId: 'c1',
    name: 'High Value Expense',
    isManagerApprover: true,
    approvers: [
      { stepNumber: 1, userId: '2', userName: 'Riya Sharma', userRole: 'MANAGER' },
      { stepNumber: 2, userId: '6', userName: 'Director', userRole: 'MANAGER' },
      { stepNumber: 3, userId: '7', userName: 'CFO', userRole: 'ADMIN' },
    ],
    approvalSequence: true,
    conditionType: 'HYBRID',
    percentageThreshold: 60,
    specificApproverId: '7',
    specificApproverName: 'CFO',
    createdAt: '2025-01-05T00:00:00Z',
  },
]

export function useApprovalRules(): UseApprovalRulesReturn {
  const [rules, setRules] = useState<ApprovalRule[]>([])
  const [loading, setLoading] = useState(false)
  const [actionLoading, setActionLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // ── Fetch all approval rules for company ───────────────────────────────────
  const fetchRules = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // GET /api/admin/approval-rules
      await new Promise((r) => setTimeout(r, 600))
      setRules(MOCK_RULES)
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to fetch rules.')
    } finally {
      setLoading(false)
    }
  }, [])

  // ── Create new rule ────────────────────────────────────────────────────────
  const createRule = async (payload: CreateApprovalRulePayload) => {
    setActionLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // POST /api/admin/approval-rules
      await new Promise((r) => setTimeout(r, 800))
      console.log('createRule placeholder', payload)
      await fetchRules()
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to create rule.')
      throw err
    } finally {
      setActionLoading(false)
    }
  }

  // ── Update existing rule ───────────────────────────────────────────────────
  const updateRule = async (id: string, payload: Partial<CreateApprovalRulePayload>) => {
    setActionLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // PATCH /api/admin/approval-rules/:id
      await new Promise((r) => setTimeout(r, 600))
      console.log('updateRule placeholder', { id, payload })
      await fetchRules()
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to update rule.')
      throw err
    } finally {
      setActionLoading(false)
    }
  }

  // ── Delete rule ────────────────────────────────────────────────────────────
  const deleteRule = async (id: string) => {
    setActionLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // DELETE /api/admin/approval-rules/:id
      await new Promise((r) => setTimeout(r, 500))
      setRules((prev) => prev.filter((r) => r.id !== id))
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to delete rule.')
      throw err
    } finally {
      setActionLoading(false)
    }
  }

  return {
    rules,
    loading,
    actionLoading,
    error,
    fetchRules,
    createRule,
    updateRule,
    deleteRule,
  }
}