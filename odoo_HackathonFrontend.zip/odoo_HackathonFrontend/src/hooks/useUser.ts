import { useState, useCallback } from 'react'
import type { User, CreateUserPayload, UserRole } from '../types'

interface UseUsersReturn {
  users: User[]
  loading: boolean
  actionLoading: boolean
  error: string | null
  fetchUsers: () => Promise<void>
  createUser: (payload: CreateUserPayload) => Promise<void>
  updateUserRole: (userId: string, role: UserRole) => Promise<void>
  assignManager: (employeeId: string, managerId: string) => Promise<void>
  deleteUser: (userId: string) => Promise<void>
}

const MOCK_USERS: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@company.com',
    role: 'ADMIN',
    companyId: 'c1',
    createdAt: '2025-01-01T00:00:00Z',
  },
  {
    id: '2',
    name: 'Riya Sharma',
    email: 'riya@company.com',
    role: 'MANAGER',
    companyId: 'c1',
    createdAt: '2025-01-05T00:00:00Z',
  },
  {
    id: '3',
    name: 'Arjun Mehta',
    email: 'arjun@company.com',
    role: 'EMPLOYEE',
    managerId: '2',
    managerName: 'Riya Sharma',
    companyId: 'c1',
    createdAt: '2025-01-10T00:00:00Z',
  },
  {
    id: '4',
    name: 'Sneha Patil',
    email: 'sneha@company.com',
    role: 'EMPLOYEE',
    managerId: '2',
    managerName: 'Riya Sharma',
    companyId: 'c1',
    createdAt: '2025-02-01T00:00:00Z',
  },
]

export function useUsers(): UseUsersReturn {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(false)
  const [actionLoading, setActionLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // ── Fetch all users in company ─────────────────────────────────────────────
  const fetchUsers = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // GET /api/admin/users
      await new Promise((r) => setTimeout(r, 600))
      setUsers(MOCK_USERS)
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to fetch users.')
    } finally {
      setLoading(false)
    }
  }, [])

  // ── Create employee or manager ─────────────────────────────────────────────
  const createUser = async (payload: CreateUserPayload) => {
    setActionLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // POST /api/admin/users
      // Body: { name, email, password, role, managerId? }
      await new Promise((r) => setTimeout(r, 800))
      console.log('createUser placeholder', payload)
      await fetchUsers()
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to create user.')
      throw err
    } finally {
      setActionLoading(false)
    }
  }

  // ── Update user role ───────────────────────────────────────────────────────
  const updateUserRole = async (userId: string, role: UserRole) => {
    setActionLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // PATCH /api/admin/users/:userId/role
      // Body: { role }
      await new Promise((r) => setTimeout(r, 500))
      setUsers((prev) =>
        prev.map((u) => (u.id === userId ? { ...u, role } : u))
      )
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to update role.')
      throw err
    } finally {
      setActionLoading(false)
    }
  }

  // ── Assign manager to employee ─────────────────────────────────────────────
  const assignManager = async (employeeId: string, managerId: string) => {
    setActionLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // PATCH /api/admin/users/:employeeId/manager
      // Body: { managerId }
      await new Promise((r) => setTimeout(r, 500))
      const manager = users.find((u) => u.id === managerId)
      setUsers((prev) =>
        prev.map((u) =>
          u.id === employeeId
            ? { ...u, managerId, managerName: manager?.name }
            : u
        )
      )
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to assign manager.')
      throw err
    } finally {
      setActionLoading(false)
    }
  }

  // ── Delete user ────────────────────────────────────────────────────────────
  const deleteUser = async (userId: string) => {
    setActionLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // DELETE /api/admin/users/:userId
      await new Promise((r) => setTimeout(r, 500))
      setUsers((prev) => prev.filter((u) => u.id !== userId))
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to delete user.')
      throw err
    } finally {
      setActionLoading(false)
    }
  }

  return {
    users,
    loading,
    actionLoading,
    error,
    fetchUsers,
    createUser,
    updateUserRole,
    assignManager,
    deleteUser,
  }
}