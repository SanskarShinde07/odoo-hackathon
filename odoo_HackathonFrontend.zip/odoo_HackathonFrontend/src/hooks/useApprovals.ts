import { useState, useCallback } from 'react'
import type { Expense } from '../types'

interface ApprovePayload {
  expenseId: string
  comment: string
}

interface RejectPayload {
  expenseId: string
  comment: string
}

interface UseApprovalsReturn {
  pendingApprovals: Expense[]
  selectedExpense: Expense | null
  loading: boolean
  actionLoading: boolean
  error: string | null
  fetchPendingApprovals: () => Promise<void>
  fetchExpenseById: (id: string) => Promise<void>
  approveExpense: (payload: ApprovePayload) => Promise<void>
  rejectExpense: (payload: RejectPayload) => Promise<void>
}

const MOCK_PENDING: Expense[] = [
  {
    id: 'e3',
    employeeId: '2',
    employeeName: 'Riya Sharma',
    amount: 150,
    currency: 'USD',
    amountInCompanyCurrency: 12500,
    companyCurrency: 'INR',
    category: 'ACCOMMODATION',
    description: 'Hotel stay during Bangalore offsite',
    date: '2025-03-20',
    status: 'IN_REVIEW',
    currentApproverStep: 1,
    totalApproverSteps: 2,
    comments: [],
    createdAt: '2025-03-20T08:00:00Z',
  },
  {
    id: 'e4',
    employeeId: '3',
    employeeName: 'Arjun Mehta',
    amount: 3400,
    currency: 'INR',
    amountInCompanyCurrency: 3400,
    companyCurrency: 'INR',
    category: 'TRAVEL',
    description: 'Flight tickets - Mumbai to Delhi',
    date: '2025-03-22',
    status: 'PENDING',
    currentApproverStep: 1,
    totalApproverSteps: 3,
    comments: [],
    createdAt: '2025-03-22T09:00:00Z',
  },
]

export function useApprovals(): UseApprovalsReturn {
  const [pendingApprovals, setPendingApprovals] = useState<Expense[]>([])
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null)
  const [loading, setLoading] = useState(false)
  const [actionLoading, setActionLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // ── Fetch expenses pending this manager's approval ─────────────────────────
  const fetchPendingApprovals = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // GET /api/approvals/pending
      // Returns expenses where current approver step = this manager's step
      await new Promise((r) => setTimeout(r, 600))
      setPendingApprovals(MOCK_PENDING)
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to fetch approvals.')
    } finally {
      setLoading(false)
    }
  }, [])

  // ── Fetch single expense detail ────────────────────────────────────────────
  const fetchExpenseById = useCallback(async (id: string) => {
    setLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // GET /api/expenses/:id
      await new Promise((r) => setTimeout(r, 400))
      const found = MOCK_PENDING.find((e) => e.id === id) ?? null
      setSelectedExpense(found)
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to fetch expense.')
    } finally {
      setLoading(false)
    }
  }, [])

  // ── Approve expense ────────────────────────────────────────────────────────
  const approveExpense = async ({ expenseId, comment }: ApprovePayload) => {
    setActionLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // POST /api/approvals/:expenseId/approve
      // Body: { comment }
      // Response: updated Expense (moves to next step or sets status = APPROVED)
      await new Promise((r) => setTimeout(r, 700))
      setPendingApprovals((prev) => prev.filter((e) => e.id !== expenseId))
      console.log('approveExpense placeholder', { expenseId, comment })
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to approve expense.')
      throw err
    } finally {
      setActionLoading(false)
    }
  }

  // ── Reject expense ─────────────────────────────────────────────────────────
  const rejectExpense = async ({ expenseId, comment }: RejectPayload) => {
    setActionLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // POST /api/approvals/:expenseId/reject
      // Body: { comment }
      await new Promise((r) => setTimeout(r, 700))
      setPendingApprovals((prev) => prev.filter((e) => e.id !== expenseId))
      console.log('rejectExpense placeholder', { expenseId, comment })
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Failed to reject expense.')
      throw err
    } finally {
      setActionLoading(false)
    }
  }

  return {
    pendingApprovals,
    selectedExpense,
    loading,
    actionLoading,
    error,
    fetchPendingApprovals,
    fetchExpenseById,
    approveExpense,
    rejectExpense,
  }
}