import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthContext } from '../context/AuthContext'
import type { User } from '../types'

// ─── Payloads ─────────────────────────────────────────────────────────────────
interface LoginPayload {
  email: string
  password: string
}

interface SignupPayload {
  name: string
  email: string
  password: string
  country: string
  currency: string
}

interface UseAuthReturn {
  loading: boolean
  error: string | null
  login: (payload: LoginPayload) => Promise<void>
  signup: (payload: SignupPayload) => Promise<void>
  logout: () => void
}

// ─── Hook ─────────────────────────────────────────────────────────────────────
export function useAuth(): UseAuthReturn {
  const { setUser, setToken, logout: ctxLogout } = useAuthContext()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const navigate = useNavigate()

  // ── Login ──────────────────────────────────────────────────────────────────
  const login = async (payload: LoginPayload) => {
    setLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // const res = await axios.post<ApiResponse<{ user: User; token: string }>>(
      //   '/api/auth/login', payload
      // )
      // setToken(res.data.data.token)
      // setUser(res.data.data.user)

      // ── PLACEHOLDER: mock login ────────────────────────────────────────────
      await new Promise((r) => setTimeout(r, 800))
      const mockUser: User = {
        id: '1',
        name: 'Demo User',
        email: payload.email,
        role: 'EMPLOYEE',
        companyId: 'c1',
        createdAt: new Date().toISOString(),
      }
      setToken('mock-token-xyz')
      setUser(mockUser)
      navigate('/employee/submit')
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Login failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  // ── Signup ─────────────────────────────────────────────────────────────────
  const signup = async (payload: SignupPayload) => {
    setLoading(true)
    setError(null)
    try {
      // TODO: Replace with real API call
      // Creates Company + Admin user in one shot
      // const res = await axios.post<ApiResponse<{ user: User; token: string }>>(
      //   '/api/auth/signup', payload
      // )
      // setToken(res.data.data.token)
      // setUser(res.data.data.user)

      // ── PLACEHOLDER ────────────────────────────────────────────────────────
      await new Promise((r) => setTimeout(r, 1000))
      const mockAdmin: User = {
        id: '1',
        name: payload.name,
        email: payload.email,
        role: 'ADMIN',
        companyId: 'c1',
        createdAt: new Date().toISOString(),
      }
      setToken('mock-token-xyz')
      setUser(mockAdmin)
      navigate('/admin/users')
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Signup failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  // ── Logout ─────────────────────────────────────────────────────────────────
  const logout = () => {
    ctxLogout()
    navigate('/login')
  }

  return { loading, error, login, signup, logout }
}