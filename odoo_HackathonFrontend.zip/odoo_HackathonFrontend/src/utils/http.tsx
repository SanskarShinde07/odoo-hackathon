import React, { useState } from 'react';
import { Button, Typography, Box, CircularProgress } from '@mui/material';

export const HttpConnectionTest: React.FC = () => {
  const [status, setStatus] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const testConnection = async () => {
    setLoading(true);
    setStatus('Testing...');
    try {
      // Replace with your actual backend API endpoint if needed
      const response = await fetch('https://jsonplaceholder.typicode.com/posts/1');
      if (response.ok) {
        const data = await response.json();
        setStatus(`Success! Status: ${response.status}. Data: ${JSON.stringify(data).substring(0, 50)}...`);
      } else {
        setStatus(`Failed with status: ${response.status}`);
      }
    } catch (error: any) {
      setStatus(`Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ p: 2, border: '1px dashed grey', borderRadius: 2, my: 2 }}>
      <Typography variant="h6" gutterBottom>
        Backend Connection Test
      </Typography>
      <Button 
        variant="contained" 
        color="primary" 
        onClick={testConnection}
        disabled={loading}
      >
        {loading ? <CircularProgress size={24} color="inherit" /> : 'Test Connection'}
      </Button>
      {status && (
        <Typography 
          variant="body1" 
          sx={{ mt: 2, p: 1, bgcolor: '#f5f5f5', borderRadius: 1, wordBreak: 'break-all' }}
        >
          {status}
        </Typography>
      )}
    </Box>
  );
};
