// ─── Roles ────────────────────────────────────────────────────────────────────
export type UserRole = 'ADMIN' | 'MANAGER' | 'EMPLOYEE'

// ─── Expense ──────────────────────────────────────────────────────────────────
export type ExpenseStatus = 'PENDING' | 'IN_REVIEW' | 'APPROVED' | 'REJECTED'

export type ExpenseCategory =
  | 'TRAVEL'
  | 'FOOD'
  | 'ACCOMMODATION'
  | 'OFFICE_SUPPLIES'
  | 'ENTERTAINMENT'
  | 'MISCELLANEOUS'

export interface ApprovalComment {
  approverId: string
  approverName: string
  comment: string
  action: 'APPROVED' | 'REJECTED'
  step: number
  timestamp: string
}

export interface Expense {
  id: string
  employeeId: string
  employeeName: string
  amount: number
  currency: string
  amountInCompanyCurrency: number
  companyCurrency: string
  category: ExpenseCategory
  description: string
  date: string
  status: ExpenseStatus
  receiptUrl?: string
  currentApproverStep: number
  totalApproverSteps: number
  approvalRuleId?: string
  comments: ApprovalComment[]
  createdAt: string
}

export interface SubmitExpensePayload {
  amount: number
  currency: string
  category: ExpenseCategory
  description: string
  date: string
  receiptFile?: File
}

// ─── Users ────────────────────────────────────────────────────────────────────
export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  managerId?: string
  managerName?: string
  companyId: string
  createdAt: string
}

export interface CreateUserPayload {
  name: string
  email: string
  password: string
  role: UserRole
  managerId?: string
}

// ─── Company ──────────────────────────────────────────────────────────────────
export interface Company {
  id: string
  name: string
  country: string
  currency: string
  currencySymbol: string
  adminId: string
}

// ─── Approval Rules ───────────────────────────────────────────────────────────
export type ApprovalConditionType =
  | 'SEQUENTIAL'
  | 'PERCENTAGE'
  | 'SPECIFIC_APPROVER'
  | 'HYBRID'

export interface ApprovalStep {
  stepNumber: number
  userId: string
  userName: string
  userRole: string
}

export interface ApprovalRule {
  id: string
  companyId: string
  name: string
  isManagerApprover: boolean   // If true, employee's direct manager is step 0
  approvers: ApprovalStep[]
  approvalSequence: boolean    // true = sequential, false = parallel
  conditionType: ApprovalConditionType
  percentageThreshold?: number       // For PERCENTAGE / HYBRID
  specificApproverId?: string        // For SPECIFIC_APPROVER / HYBRID
  specificApproverName?: string
  createdAt: string
}

export interface CreateApprovalRulePayload {
  name: string
  isManagerApprover: boolean
  approvers: Omit<ApprovalStep, 'userName' | 'userRole'>[]
  approvalSequence: boolean
  conditionType: ApprovalConditionType
  percentageThreshold?: number
  specificApproverId?: string
}

// ─── Country / Currency (from restcountries API) ──────────────────────────────
export interface Country {
  name: { common: string; official: string }
  currencies: Record<string, { name: string; symbol: string }>
}

export interface CurrencyOption {
  countryName: string
  currencyCode: string
  currencyName: string
  currencySymbol: string
}

// ─── API Responses ────────────────────────────────────────────────────────────
export interface ApiResponse<T> {
  data: T
  message?: string
  success: boolean
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  pageSize: number
}